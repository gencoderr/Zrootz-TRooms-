(ns store_credit.test.core
  (:use [store_credit.core])
  (:use [clojure.test]))

(deftest replace-me ;; FIXME: write
  (is false "No tests have been written."))
