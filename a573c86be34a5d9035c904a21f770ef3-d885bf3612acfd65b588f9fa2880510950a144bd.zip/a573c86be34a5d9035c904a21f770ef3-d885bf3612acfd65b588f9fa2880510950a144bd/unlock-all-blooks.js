async function lazyDefine(callback, condition, maxAttempts = 100, time = 100) {
    let attempt = 0;

    while (attempt < maxAttempts) {
        const result = callback();

        if (condition ? condition(result) : result) return result;
        await new Promise(res => setTimeout(res, time));

        attempt++;
    }

    return null;
}

function instead(object, name, callback) {
    const orig = object[name];

    object[name] = function (...args) {
        return callback(this, args, orig);
    }

    return () => (object[name] = orig);
}

window.reactHandler = async () => {
    const getFiber = (node) => Object.values(node)?.[1]?.children[1]?._owner;
    const handler = await lazyDefine(
        () => document.querySelector('#app > div > div'),

        // This is necessary because null's type is "object"
        target => {
            if (!target) return false;

            const node = getFiber(target).stateNode;
            return node && typeof node === 'object';
        },

        undefined,
        Infinity
    );

    return getFiber(handler);
};

let blooks;
function callback(self, args, orig) {
    if (!('Chick' in args[0])) return orig.apply(self, args);

    blooks = args[0];
    return orig.apply(self, args);
}

const unpatchKeys = instead(Object, 'keys', callback);
const unpatchEntries = instead(Object, 'entries', callback);
window.getBlooks = () => Object.keys(blooks).filter(blook => blook !== 'Dull Blue');

window.main = async function () {
    await lazyDefine(() => document.querySelector('[class*="_blooksHolder_"]'));
    await lazyDefine(() => blooks);
    const handler = await window.reactHandler();

    unpatchKeys();
    unpatchEntries();

    if (handler?.stateNode?.state?.blookData) {
        console.info('Applying blooks to dashboard...');

        handler.stateNode.setState({
            allSets: [
                ...new Set([
                    ...handler.stateNode.state.allSets,
                    'Blizzard',
                    'Spooky',
                    'Hidden',
                    'Color'
                ])
            ],

            blookData: (
                [...new Set([
                    ...Object.keys(handler.stateNode.state.blookData),
                    ...window.getBlooks(),
                ])]
            ).reduce((acc, blook) => ({ ...acc, [blook]: 39 }), {}),

            blook: 'Spooky Ghost'
        });

        handler.stateNode.forceUpdate();
    }

    if (handler?.stateNode?.state?.unlocks) {
        console.info('Applying blooks to lobby...');

        handler.stateNode.setState({
            // Ensure that there are no duplicate blooks
            unlocks: [...new Set([
                ...handler.stateNode.state.unlocks,
                ...window.getBlooks(),
            ])],

            takenBlooks: []
        });

        handler.stateNode.forceUpdate();

        // This needs no timeout, it just needs to be pushed on the event stack
        // and therefore not executed eagerly.
        setTimeout(() => handler.stateNode.setBlook('Spooky Ghost'));
    }
}

// Detect when the user navigates to "/play/lobby" as that's
// the path we need to be in to yield any handlers.
const paths = ['/play/lobby', '/blooks'];
instead(history, 'pushState', (self, args, orig) => {
    if (paths.some(path => args.includes(path))) {
        window.main();
    }

    return orig.apply(self, args);
})

if (paths.includes(window.location.pathname)) {
    window.main();
}