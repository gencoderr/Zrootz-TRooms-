object Project {
    object Android {
        const val compileSdkVersion = 28
        const val targetSdkVersion = 28
        const val minSdkVersion = 21
        const val testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }
}
