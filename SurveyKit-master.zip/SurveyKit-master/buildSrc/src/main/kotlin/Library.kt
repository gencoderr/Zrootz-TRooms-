object Library {
    const val version = "2.0.0-alpha-4"
}
