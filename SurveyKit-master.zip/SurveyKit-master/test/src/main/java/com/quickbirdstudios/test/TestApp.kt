package com.quickbirdstudios.test

import android.app.Application

internal class TestApp : Application()
