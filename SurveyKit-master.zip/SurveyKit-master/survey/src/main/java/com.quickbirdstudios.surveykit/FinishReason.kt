package com.quickbirdstudios.surveykit

// TODO check if Saved can be removed
enum class FinishReason {
    Saved, Discarded, Completed, Failed;
}
