package com.quickbirdstudios.surveykit.backend.views.step

import com.quickbirdstudios.surveykit.StepIdentifier

interface Identifiable {
    val id: StepIdentifier
}
