package com.quickbirdstudios.example

import android.app.Application

class App : Application()
