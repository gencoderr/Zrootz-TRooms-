# Fish-Spoofer

## Features

1. **Temp Spoof**
   - EasyAntiCheat
   - BattleEye
2. **Change MAC**
   - Custom MAC
   - Random MAC
3. **PC Spoof**
   - Spoof Disks
   - Spoof GUID
4. **Network**
   - Fix Network
   - Flush DNS

## Installation Guide

### Option 1: Clone the Repository

```bash
git clone https://github.com/official-notfishvr/Fish-Spoofer.git
cd Fish-Spoofer
```

### Option 2: Download the EXE

For a quick setup, download the EXE directly from the [releases page](https://github.com/official-notfishvr/Fish-Spoofer/releases/download/V1/Fish-Spoofer.exe).
